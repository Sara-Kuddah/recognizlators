//
//  ImageRecView.swift
//  Recognizlator
//
//  Created by sara ayed albogami on 21/07/1444 AH.
//

import SwiftUI
import CoreML
import Vision


import SwiftUI
import CoreML
import Vision

struct ImageRecView: View {
    
    @State private var showSheet: Bool = false
    @State private var showPhotoOptions: Bool = false
    @State private var image: UIImage?
    @State private var inputlang = ""
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State private var classificationLabel: String = ""
    
    private let classifier = VisionClassifier(mlModel: MobileNetV2().model)
    
    @State  private var languages :[String] =
    [NSLocalizedString("English", comment: ""),
     NSLocalizedString("Arabic", comment: ""),
     NSLocalizedString("Chinese", comment: ""),
     NSLocalizedString("French", comment: ""),
     NSLocalizedString("Italian", comment: "")]
    
    var body: some View {
        
        NavigationView {
            
            VStack {
                
                HStack(spacing:35){
                    
                    Picker("Select language", selection: $inputlang){
                        ForEach(languages , id: \.self){ language in
                            Text(language)
                                .accessibilityLabel(Text(language))
                        }
                    }
                    .accessibilityLabel(Text("Select language"))
                    .pickerStyle(.menu)
                    .accentColor(.white)
                    .font(Font.custom("SF Pro", size: 18))
                    .frame(width: 300 , height: 50)
                    .background(RoundedRectangle(cornerRadius: 15 ).fill(Color("Blue")).opacity(1))
                    .shadow(
                        color: Color.gray.opacity(0.2),
                        radius: 5,
                        x: -8,
                        y: 8 )
                    
                }
                
                Section{
                    
                    Image(uiImage: (image ?? UIImage(named: "Image"))!)
                        .resizable()
                        .cornerRadius(16)
                        .frame(width: 350, height: 300)

                }.padding(.all)
                
                Button("Choose Picture") {
                    // open action sheet
                    self.showSheet = true
                    
                }.padding()
                    .accentColor(.white)
                    .font(Font.custom("SF Pro", size: 18))
                    .frame(width: 250 , height: 50)
                    .background(RoundedRectangle(cornerRadius: 15 ).fill(Color("Blue")).opacity(1))
                    .shadow(
                        color: Color.gray.opacity(0.2),
                        radius: 5,
                        x: -8,
                        y: 8 )
                    
                    .actionSheet(isPresented: $showSheet) {
                        ActionSheet(title: Text("Select Photo"), message: Text("Choose"), buttons: [
                            .default(Text("Photo Library")) {
                                // open photo library
                                self.showPhotoOptions = true
                                self.sourceType = .photoLibrary
                            },
                            .default(Text("Camera")) {
                                // open camera
                                self.showPhotoOptions = true
                                self.sourceType = .camera
                            },
                            .cancel()
                        ])
                        
                }
                    .padding()
                HStack{
                    Text("Image categories:")
                    Text(classificationLabel)
                        
                } .font(Font.custom("SF Pro", size: 18))
                
                HStack{
                    Text("Translated text:")
                        .font(Font.custom("SF Pro", size: 18))
                    
                }
                .padding(.all)
            }
            .navigationBarTitle("")
        }.sheet(isPresented: $showPhotoOptions) {
            ImagePicker(image: self.$image, isShown: self.$showPhotoOptions, sourceType: self.sourceType)
                .onDisappear{
                    if image != nil {
                        classifier?.classify(self.image!) {
                            result in
                                self.classificationLabel = result
                        }
                    }
                }
        }
    }
}

struct ImageRecView_Previews: PreviewProvider {
    static var previews: some View {
        
        Group {
            // 1
            ImageRecView()
                .environment(\.locale, .init(identifier: "en"))
            // 2
            ImageRecView()
                .environment(\.locale, .init(identifier: "ar"))
        }
    }
}

