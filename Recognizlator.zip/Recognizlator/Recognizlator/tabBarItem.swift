//
//  tabBarItem.swift
//  Recognizlator
//
//  Created by sara ayed albogami on 21/07/1444 AH.
//


import Foundation

enum TabBarItem: CaseIterable {
    case home
    case imageRec
    case History
   
    
    var title: String {
        switch self {
        case .home:     return NSLocalizedString("Text Rec", comment: "") 
        case .imageRec:   return NSLocalizedString("Image Rec", comment: "")
        case .History:   return NSLocalizedString("History", comment: "")
        }
    }
    
    var imageName: String {
        switch self {
        case .home:     return "text.aligncenter"
        case .imageRec:   return "photo"
        case .History:   return "square.and.pencil.circle"
 
        }
    }
}
